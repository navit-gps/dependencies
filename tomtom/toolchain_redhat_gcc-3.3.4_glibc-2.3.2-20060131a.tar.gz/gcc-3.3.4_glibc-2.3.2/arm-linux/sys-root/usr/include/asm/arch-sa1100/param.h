/*
 * linux/include/asm-arm/arch-sa1100/param.h
 */
