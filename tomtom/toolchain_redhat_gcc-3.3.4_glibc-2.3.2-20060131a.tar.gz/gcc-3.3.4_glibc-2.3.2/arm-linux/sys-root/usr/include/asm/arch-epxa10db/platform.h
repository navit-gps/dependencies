#ifndef PLATFORM_H
#define PLATFORM_H
#include "excalibur.h"

#define MAXIRQNUM 15 
#endif

