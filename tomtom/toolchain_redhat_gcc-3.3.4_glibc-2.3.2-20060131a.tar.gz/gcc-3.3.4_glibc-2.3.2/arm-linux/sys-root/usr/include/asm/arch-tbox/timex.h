/*
 * linux/include/asm-arm/arch-tbox/timex.h
 *
 * Tbox timex specifications
 *
 * Copyright (C) 1999 Philip Blundell
 */

