/*
 * linux/include/asm-arm/arch-arc/param.h
 */
