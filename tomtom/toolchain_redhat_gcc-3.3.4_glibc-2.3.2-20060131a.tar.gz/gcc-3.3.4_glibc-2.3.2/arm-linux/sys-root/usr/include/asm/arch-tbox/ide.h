/*
 * linux/include/asm-arm/arch-tbox/ide.h
 */
