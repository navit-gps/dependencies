/*
 *  linux/include/asm-arm/arch-mx1ads/keyboard.h
 *
 *  Copyright (C) 2002 Shane Nay (shane@minirl.com)
 *
 * Well..., what did you expect?, it's not really there :)
 *
 */
#define kbd_init_hw()           do { } while (0)
#define kbd_enable_irq()        do { } while (0)
#define kbd_disable_irq()       do { } while (0)
