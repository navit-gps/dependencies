/*
 * linux/include/asm-arm/arch-ebsa110/param.h
 */
