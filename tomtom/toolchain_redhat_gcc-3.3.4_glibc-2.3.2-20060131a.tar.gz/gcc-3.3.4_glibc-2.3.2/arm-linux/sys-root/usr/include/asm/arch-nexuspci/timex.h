/*
 * linux/include/asm-arm/arch-nexuspci/timex.h
 *
 * NexusPCI StrongARM card timex specifications
 *
 * Copyright (C) 1998 Philip Blundell
 */

