/*
 * linux/include/asm-arm/arch-shark/timex.h
 *
 * by Alexander Schulz
 */
